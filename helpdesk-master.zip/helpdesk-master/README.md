## OrgSync ZenDesk Theme

### Makeup of this Repo

All the files in this main directory are named to match the layouts defined in ZenDesk's custom theme editor.
The CSS.css and JS.js are for their respective tabs in the editor.
The assets folder is any files that are uploaded to the assets tab.
